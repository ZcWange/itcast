function  Person(name) {
  this.name = name || 'person'
  this.eat = function () {
    console.log('eatting')
  }
}

Person.prototype.sayHi = function() {
  console.log('hello world')
}

var p = new Person()
