// 【准备工作：获取元素】
var ul = document.querySelector('#list'); // 轮播项整体
var btnLeft = document.querySelector('#btnLeft'); // 左按钮
var btnRight = document.querySelector('#btnRight'); //右按钮
var control = document.querySelector('.control'); // 小点按钮的父元素
var banner = document.querySelector('#banner'); // 轮播区域元素
var links = control.children; // 一组小点按钮
var index = 0; // 定义一个变量，表示当前显示的轮播项

// 【功能1：点击右侧按钮实现轮播】
// 1 给右侧按钮注册onclick事件
btnRight.onclick = function () {
  // 判断索引是否是0，若是0，则设置ul的left值为0
  if (index == 0) {
    ul.style.left = 0 + 'px';
  }
  // 1.1 把之前的a的样式恢复默认，去掉类名active
  links[index].className = '';
  // 2 index++（注意：index加之前和之后区别）
  index++;
  // 3 计算ul的运动的目标值
  var v = index * -790;
  // 3.1 限制
  if (index > 6) {
    // 限制的目的，解决切换小点按钮样式报错问题
    index = 0;
  }

  // 4.运动ul
  animate(ul, v, 50);
  // 5. 找到对应的a，添加类名，突出显示
  links[index].className = 'active';

}
// 【功能2：点击左侧按钮实现轮播】
// 1. 给左侧按钮注册onclick事件
btnLeft.onclick = function () {
  // 1.1 之前的a的类名去掉，恢复默认
  links[index].className = '';
  // 2. 切换下一项
  index--;
  // 3. 限制
  if (index < 0) {
    // 把ul的left值变为-5530px，回到第七个（7和0长的一样）
    ul.style.left = '-5530px';
    //更改索引
    index = 6;
  }
  // 4. 计算目标值
  var v = index * -790;
  // 5. 运动ul
  animate(ul, v, 50);
  // 6. 之后的a类名加上，突出显示
  links[index].className = 'active';
};

// 【功能3：点击小点点按钮实现轮播】
// 0. 循环遍历每一个小点，设置自定义标签属性num，表示第几个a(从0开始)
for (var i = 0; i < links.length; i++) {
  links[i].setAttribute('num', i);
}


// 1. 给类名为control的div注册点击事件
control.onclick = function (e) {
  // 2. 通过事件对象.target属性获取最先触发的元素
  var t = e.target;
  // 3. 通过nodeName属性判断是否是a
  if (t.nodeName == 'A') {
    // 上一项
    links[index].className = '';
    // 下一项
    index = Number(t.getAttribute('num'));
    // 计算ul的目标值
    var v = index * -790;
    // 把ul运动到目标值
    animate(ul, v, 50);
    links[index].className = 'active';
  }
};


// 【功能4：自动轮播】
var flag2 = setInterval(function () {
  btnRight.onclick();
}, 2000);

banner.onmouseenter = function () {
  // 鼠标进入banner，停止自动轮播
  clearInterval(flag2);
};

banner.onmouseleave = function () {
  // 重新启动自动轮播
  flag2 = setInterval(function () {
    btnRight.onclick();
  }, 2000);
};
/*
  功能：动画
  参数：
    element  要运动的元素（盒子）
    targetValue 目标值    数字
    speed 速度     数字
*/
var flag; // 全局变量，表示着定时器的标识
function animate(element, targetValue, speed) {
  // 0. 清除旧的定时器
  clearInterval(flag);
  // 动画
  // 1. 产生一个定时器
  flag = setInterval(function () {
    // 2. 获取原有的left值
    var v = element.offsetLeft;
    // 2.1 判断是否到达目标
    if (v == targetValue) {
      // 清除定时器，保证下一次这个函数不会执行。
      clearInterval(flag);
      // 结束函数本次的执行
      return;
    }
    // 3. 更改盒子的样式值
    // 3.1 判断是否是最后一步
    if (Math.abs(targetValue - v) < speed) {
      // 说明是最后一步，并且最后一步可能要越界，把物体直接设置为目标值
      element.style.left = targetValue + 'px';
    } else {
      // 3.2. 判断将来是正方向还是反方向
      if (targetValue > v) {
        element.style.left = v + speed + 'px';
      } else {
        element.style.left = v - speed + 'px';
      }
    }
  }, 10);
};
