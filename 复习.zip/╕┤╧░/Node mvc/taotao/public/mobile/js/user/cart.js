$(function () {
    // 需求
    // 1. 页面初始化 ,自己下拉的时候,点击刷新按钮  触发下拉刷新  去加载数据  渲染页面
    // 2. 编辑
    // 3. 删除
    // 4. 计算订单总额
    new App();
})
var App = function () {
    this.$el = $('.mui-scroll');
    this.init();
}
App.prototype.init = function () {
    this.initPullRefreshDown();
    this.bindEvent();
}
App.prototype.render = function (callback) {
    var that = this;
    // 获取数据
    $.ajax({
        type: 'get',
        url: '/cart/queryCart',
        data: '',
        dataType: 'json',
        success: function (data) {
            // 数据缓存
            that.cartList = data;
            setTimeout(function () {
                callback && callback(data);
            },700)
        }
    })
}
App.prototype.bindEvent = function () {
    // 点击刷新触发下拉
    $('.fa-refresh').on('tap',function () {
        mui('.mui-scroll-wrapper').pullRefresh().pulldownLoading();
    })
    var that = this;
    // 编辑
    that.$el.on('tap','.mui-icon-compose', function () {
        that.editCart(this);
    }).on('tap', '.mui-icon-trash', function () {
        that.delCart(this);
    }).on('change', 'input', function () {
        // 根据当前的是否选中  去给对应的数据添加一个标识
        var isChecked = $(this).prop('checked');
        var cart = that.cartList[this.dataset.index];
        cart.isChecked = isChecked;
        that.calcAmount();
    })
}
App.prototype.initPullRefreshDown = function () {
    var that = this;
    mui.init({
        pullRefresh:{
            container: '.mui-scroll-wrapper',
            indicators: false,
            down: {
                auto: true,
                callback:function () {
                    var _self = this;
                    that.render(function (data) {
                        // 渲染
                        that.$el.html(template('cart', data));
                        // 结束下拉刷新
                        _self.endPulldownToRefresh();
                    })
                }
            }
        }
    })
}
// 编辑购物车
App.prototype.editCart = function (btn) {
    var that = this;
    // 弹窗   有内容  写在模板中 因为需要动态渲染
    // 获取当前编辑的购物车商品的所有信息
    var cart = that.cartList[btn.dataset.index];
    var html = template('edit', cart).replace(/\n/g,'');
    mui.confirm(html,'编辑商品',['取消','确认'],function (e) {
        if(e.index ===1 ) {
            // 确认后做什么
            var size = $('.pro_size span.now').data('size');
            var num = mui('.mui-numbox').numbox().getValue();
            $.ajax({
                type: 'post',
                url: '/cart/updateCart',
                data: {
                    id: cart.id,
                    size: size,
                    num: num
                },
                dataType: 'json',
                success: function (data) {
                    if (data.success) {
                        // 编辑成功
                        // 不建议重新向后台发请求获取新的列表信息
                        // 修改页面渲染时用的数据  根据数据重新渲染
                        cart.size = size;
                        cart.num = num;
                        that.$el.html(template('cart', that.cartList));
                        mui.toast('编辑成功');
                        that.calcAmount();
                    }
                }
            })
        }
    })
    // 在弹出框生成后   选择尺码  选择数量  初始化
    that.initConfirm();
}
App.prototype.initConfirm = function () {
    // 选择尺码  选择数量  初始化
    $('.pro_size span').on('tap', function () {
        $(this).addClass('now').siblings('span').removeClass('now');
    });
    mui('.mui-numbox').numbox();
}
// 删除购物车
App.prototype.delCart = function (btn) {
    var that = this;
    var cart = that.cartList[btn.dataset.index];
    mui.confirm('亲,请确认是否删除该商品','温馨提示' ['取消','确认'], function (e) {
        if (e.index ===1 ) {
            $.ajax({
                type: 'get',
                url: '/cart/deleteCart',
                data: {
                    id: cart.id
                },
                dataType: 'json',
                success: function (data) {
                    if (data.success) {
                        // 删除成功
                        that.cartList.splice(btn.dataset.index, 1);
                        that.$el.html(template('cart', that.cartList));
                        mui.toast('删除成功');
                        that.calcAmount();
                    }
                }
            })
        }
    })
}
// 计算金额
App.prototype.calcAmount = function () {
    // 选择复选框  编辑 删除
    // 获取选中的复选框   遍历复选框  去that.cartList中取  取得时候有需要遍历
    // 遍历一次  that.cartList  过程中得知 每一条数据是否是选中的状态
    var amount = 0;
    this.cartList.forEach(function (val) {
        if (val.isChecked) {
            amount += val.num * val.price;
        }
    })
    $('.tt_amount span').html(amount.toFixed(2));
}