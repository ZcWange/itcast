$(function () {
    $('form').on('submit',function (e) {
        e.preventDefault();
        // ajax提交
        var data = {
            username: $('[type="text"]').val(),
            password: $('[type="password"]').val()
        }
        if(!data.username) {
            mui.toast('请输入用户名');
            return;
        }
        if(!data.password) {
            mui.toast('请输入密码');
            return;
        }
        $.ajax({
            type: 'post',
            url: '/user/login',
            data: data,
            dataType: 'json',
            success: function (data) {
                // 登录成功
                if(data.success) {
                    // 获取地址是否会跳地址
                    var returnUrl = tt.getParamsByUrl().returnUrl;
                    if(returnUrl) {
                        location.href = returnUrl;
                    }else {
                        location.href  ='/mobile/user/index.html'
                    }
                }else {
                    mui.toast(data.message);
                }
            }
        })
    })
})