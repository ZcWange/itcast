$(function() {
    // 区域滚动
    // mui('.mui-scroll-wrapper').scroll({indicators:false});
    // 下拉刷新  上拉加载  基于 区域滚动实现
    // mui.init({
    //     // 需要初始化的组件
    //     // 拉刷新组件
    //     pullRefresh:{
    //         // 需要初始化哪个容器称为组件
    //         container:'.mui-scroll-wrapper',
    //         // 下拉刷新
    //         down:{
    //             auto:true,  // 需要在页面初始化的时候自动下拉一次
    //             callback:function () {
    //                 // console.log(this === mui('.mui-scroll-wrapper').pullRefresh());
    //                 // this是当前的组件对象
    //                 // 在你释放下拉操作的时候   触发这个回调函数
    //                 // 向后台拉取数据   拉取数据需要时间
    //                 // 拉取成功后  清除正在刷新的效果
    //                 var _self = this;
    //                 setTimeout(function () {
    //                     // mui('.mui-scroll-wrapper').pullRefresh().endPulldownToRefresh();\
    //                     _self.endPulldownToRefresh();
    //                 },1000);
    //             }
    //         }
    //         // 上拉加载
    //         up:{
    //             callback:function () {
    //                 // 在你释放上拉操作的时候  触发这个回调函数
    //                 // 获取下一页的商品数据   更多数据
    //                 // 在拉取成功后  清除正在加载的效果
    //                 var _self = this;
    //                 setTimeout(function () {
    //                     // false  是默认的  代表有数据  true  代表没有数据
    //                     _self.endPullupToRefresh();
    //                 },1000);
    //             }
    //         }
    //     }
    // })

    // 1. 初始化  获取地址栏参数设置给搜索框
    // 2. 初始化  主动触发一次下拉刷新  去加载第一页的商品数据且完成渲染
    // 3. 当下拉操作后  重新向后台获取数据 且 完成页面渲染
    // 4. 当上啦操作后  去加载下一页数据   且 完成页面渲染
    // 5. 点击搜索后  根据输入的内容重新搜索   获取第一页数据 且  完成页面渲染
    // 6. 点击排序  根据当前的排序类型  和 升序还是降序  去更新列表(获取第一页数据 且 完成渲染)
    new App();
})
var App = function() {
    this.proName = tt.getParamsByUrl().proName;
    this.page = 1;
    this.pageSize = 4;
    // 设置搜索内容给搜索框
    this.$searchInput = $('.tt_search input').val(this.proName);
    this.$searchBtn = $('.tt_search a');
    // 排序容器
    this.$order = $('.tt_order');
    // 产品容器  待渲染
    this.$product = $('.tt_product');
    this.init();
}
App.prototype.init = function() {
    var that = this;
    that.initPullRefresh();
    that.bindEvent();
}
// 获取数据  但是渲染交给回调函数去做了  渲染方式不同
App.prototype.render = function(callback) {
    var that = this;
    var params = {
        proName: that.proName,
        page: that.page,
        pageSize: that.pageSize
    };
    // 点过排序
    if(that.orderType) {
        // 动态插入属性和值
        params[that.orderType] = that.orderValue;
    }
    // 实现获取数据  成功后去调用回调函数  传入数据给回调函数
    $.ajax({
        type: 'get',
        url: '/product/queryProduct',
        data: params ,//{
            // proName: that.proName,
            // page: that.page,
            // pageSize: that.pageSize,
            // [that.orderType]: that.orderValue
            // price:1   这里只能使用一种排序类型  只能有一个排序的属性  只能动态的插入属性和值
            // num:1
        //},
        dataType: 'json',
        success: function(data) {
            // 为了测试效果添加的  实际工作中千万不要写
            setTimeout(function () {
                callback && callback(data);
            },500)
        }
    });
}
// 初始化上拉下拉组件
App.prototype.initPullRefresh = function() {
    var that = this;
    mui.init({
        pullRefresh: {
            container: '.mui-scroll-wrapper',
            indicators: false,
            down: {
                auto: true,
                callback: function() {
                    var _self = this;
                    that.page = 1;
                    that.render(function(res) {
                        //渲染后  清除下拉效果  替换内容
                        that.$product.html(template('product', res));
                        _self.endPulldownToRefresh();
                        // 开启上拉加载功能  目的: 以前加载的时候可以禁用了上拉加载功能
                        _self.refresh(true);
                    });
                }
            },
            up: {
                callback: function() {
                    var _self = this;
                    that.page++
                    that.render(function(res) {
                        //渲染后  清除上拉效果  追加内容
                        that.$product.append(template('product',res));
                        _self.endPullupToRefresh(!res.data.length);
                    });
                }
            }
        }
    })
}
// 绑定事件
App.prototype.bindEvent = function() {
    var that = this;
    that.$searchBtn.on('tap',function () {
        that.search();
    })
    that.$order.on('tap','a',function () {
        that.order(this);
    })
}
// 搜索操作
App.prototype.search = function() {
    var that = this;
    // 1. 获取输入的内容
    var value = $.trim(that.$searchInput.val());
    // 2. 简单校验一下输入内容
    if(!value){
        mui.toast('请输入关键字');
        return;
    }
    // 3. 根据输入内容进行渲染
    that.proName = value;
    // 4. 通过下拉刷新操作更新内容   触发回调函数   调用render
    //通过程序是可以控制下拉操作的  函数的名称  pulldownLoading
    mui('.mui-scroll-wrapper').pullRefresh().pulldownLoading();

}
// 排序操作
App.prototype.order = function(btn) {
    // 样式的切换
    var $curr = $(btn);
    var $currSpan = $curr.find('span');
    // 选中
    if($curr.hasClass('now')) {
        if($currSpan.hasClass('fa-angle-down')) {
            $currSpan.attr('class','fa fa-angle-up');
        }else {
            $currSpan.attr('class','fa fa-angle-down');
        }
    }else {
        // 没有选中
        $curr.addClass('now').siblings('a').removeClass('now').find('span').attr('class','fa fa-angle-down');
    }
    // 根据当前的排序类型  和  是升还是降序  去渲染页面
    //根据当前的排序类型  和 是升还是降 去渲染页面
    //price   |否|使用价格排序（1升序，2降序）
    //num     |否|产品库存排序（1升序，2降序）
    this.orderType = $curr.data('type');
    this.orderValue = $currSpan.hasClass('fa-angle-down') ? 2 : 1;
    // 数据在调用ajax的时候传递给后台
    // 触发一次下拉刷新操作   触发回调函数  调用render
    mui('.mui-scroll-wrapper').pullRefresh().pulldownLoading();
    // 下拉刷新  上拉加载 禁用了 a的跳转绑定的是tap事件   button的默认行为没有阻止
}