$(function() {
    // 1. 画面初始化  渲染历史记录列表
    // 2. 点击搜索  根据输入的 关键字  跳转页面 且 追加历史记录
    // 2.1 追加的时候是分情况
    // a) 当你输入的内容之前也搜索过  删除之前的  追加新的
    // b) 如果存储的条数已经到了10条  删除最开始的 追加新的
    // c) 正常 追加新的
    // 3. 点击删除 对应的删除搜索记录
    // 4. 点击清空  清除所有的历史记录
    new App();
});
var App = function() {
    // $el 带动态渲染的容器
    this.$el = $('.tt_history');
    this.key = 'tt_hm_history_59';
    $('.tt_search input').val(''); //清空输入框在页面初始化的时候
    // 数据类型是array   获取的本地存储中的列表数据
    this.list = JSON.parse(localStorage.getItem(this.key) || '[]');
    this.init();
};
// 入口函数
App.prototype.init = function() {
    this.render();
    this.bindEvent();
}
// 默认渲染
App.prototype.render = function() {
    // 数据  在 localStorage 中
    // 约定  KEY tt_hm_history_59  VALUE '["a","b"]'
    // 模板的语法有两种  简洁语法{{}}  原生语法  <% 任何js语法 %>
    // arr-template 无法使用模板外的变量  只能使用传入的数据
    this.$el.html(template('history', {list: this.list, ec: encodeURIComponent}));
}
// 绑定事件
App.prototype.bindEvent = function() {
    var that = this;
    // 点击搜索
    $('.tt_search').on('tap', 'a', function() {
        var value = $.trim($('.tt_search').find('input').val());
        // 未输入内容
        if (!value) {
            mui.toast('请输入关键字');
            return;
        }
        // 已经有内容
        that.pushHistory(value);
    })
    // 点击删除
    that.$el.on('tap', '.fa-close', function() {
            that.delHistory(this);
        })
        // 点击清空
        .on('tap', '.head a', function() {
            that.clearHistory();
        })
}
// 追加历史
App.prototype.pushHistory = function(value) {
    // 有没有相同的
    var isSame = false;
    var isSameIndex = null;
    this.list.forEach(function(val, i) {
        if (val === value) {
            //相同
            isSame = true;
            isSameIndex = i;
        }
    })
    if (isSame) {
        // 删除之前  索引
        this.list.splice(isSameindex, 1);
    }
    // 是否已经有十条
    else if (this.list.length >= 10) {
        //删除第一条
        this.list.splice(0, 1);
    }
    // 正常
    // 追加新的
    this.list.push(value);
    // 一直在操作内存中的 list
    //存储在本地
    localStorage.setItem(this.key, JSON.stringify(this.list));
    //跳转到下一个页面
    location.href = 'searchList.html?proName=' + encodeURIComponent(value);
}
// 删除历史
App.prototype.delHistory = function(btn) {
    this.list.splice(btn.dataset.index, 1);
    this.render();
    // 更新本地存储
    localStorage.setItem(this.key, JSON.stringify(this.list));
}
// 清空历史
App.prototype.clearHistory = function() {
    this.list = [];
    this.render();
    // 更新本地存储
    localStorage.setItem(this.key, JSON.stringify(this.list));
}