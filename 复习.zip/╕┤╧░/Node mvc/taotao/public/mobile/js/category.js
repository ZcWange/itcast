$(function() {
    // 初始化区域滚动组件
    // mui.min.js  提供了一个 mui 全局对象
    // mui('.mui-scroll-wrapper').scroll({indicators:false});
    // 1. 初始化渲染
    // 1.1 获取顶级分类数据渲染成页面
    // 1.2 根据顶级分类的第一个分类  去加载对应的品牌数据且完成渲染
    // 2. 点击顶级分类加载对应的品牌数据且完成渲染

    // 面向对象  功能模块化  利于维护 业务可读性更高
    new App();
});
var App = function() {
    // 设置顶级分类容器
    this.$top = $('.tt_cateLeft');
    // 设置二级分类容器
    this.$second = $('.tt_cateRight');
    this.init();
};
App.prototype.init = function() {
    // 页面初始化调用  对象的入口函数
    this.render();
    this.bindEvent();
}
// 渲染
App.prototype.render = function() {
    // 应该在top请求响应结束后再能获取ID
    // 传入顶级分类中的第一个分类的ID
    var that = this;
    this.renderTop(function(topId) {
        that.renderSecond(topId);
    });

}
// 渲染顶级分类
App.prototype.renderTop = function(callback) {
    var that = this;
    // 1. 获取顶级分类数据
    $.ajax({
        type: 'get',
        url: '/category/queryTopCategory',
        data: '',
        dataType: 'json',
        success: function(data) {
            // 2. 根据数据渲染页面  使用模板引擎
            // 使用模板引擎步骤
            // a 准备数据
            // b 准备模板  script - type='text/template'  模板字符
            // c 调用模板引擎函数将数据转换为HTML格式的字符串
            // d 使用模板语法将数据和HTML进行绑定
            // e 第一种: 如果传入的是对象 在模板内可以直接使用对象的属性当做变量  传入的数据源在模板内对应的变量$data
            // f 第二种: 如果传入的是数组 那么只能通过$data去操作
            that.$top.html(template('top', data));
            var topId = data.rows[0].id;
            callback && callback(topId);
            // that.renderSection(topId);  会使业务嵌套   函数的功能不够单一
        }
    })

}
//渲染品牌分类
App.prototype.renderSecond = function(topId) {
    // 需要顶级分类id
    var that = this;
    $.ajax({
        type: 'get',
        url: '/category/querySecondCategory',
        data: {
            id: topId
        },
        dataType: 'json',
        success: function(data) {
            that.$second.html(template('second', data));
        }
    })
}
//绑定事件
App.prototype.bindEvent = function() {
    var that = this;
    // 不建议在移动端使用click当做点击事件
    // 因为: click在移动端触发有300ms的延时  (在移动端双击进行缩放操作)
    // 应该:  使用更快的点击操作 来操作点击事件 top手势事件 (touchstart-touchend)
    // 使用tap 依赖第三方的库或者框架  zepto touch 模块  或者 mui 也封装了tap事件
    that.$top.on('tap', 'a', function() {
        if ($(this).parent().hasClass('now')) return; // 已经选中阻止程序执行
        // 切换样式
        $(this).parent().addClass('now').siblings('li').removeClass('now');
        // 对应去渲染二级分类
        that.renderSecond(this.dataset.id);
    })
}