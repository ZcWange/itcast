$(function() {
    // 初始化区域滚动组件
    // mui.min.js  提供了一个 mui 全局对象
    mui('.mui-scroll-wrapper').scroll({
        indicators: false
    });
    mui('.mui-slider').slider({
        interval: 5000
    });
})