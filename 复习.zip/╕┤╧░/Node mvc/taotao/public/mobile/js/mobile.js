// 已经存在 tt 的全局变量
if (!window.tt) {
    // 你只需要注意tt  是否会污染其他变量
    window.tt = {};
}
// 定义公用函数  工具函数
// 获取地址栏上的数据
//?proName=abc&size=10  {proName:'abc',size:10}
tt.getParamsByUrl = function() {
    var obj = {};
    // 不能出现特殊字符  不能出现中文字符  (IE下地址栏传参会乱码)
    //如果出现特殊字符 进行URL转码  方法encodeURIComponent  将字符串转换为 URL
    // URL转换成字符串   方法decodeURIComponent   
    // 业务实现 
    var search = location.search;
    if (search) {
        search = search.replace(/^\?/, '');
        // proName=abc&size=10;
        var arr = search.split('&');
        arr.forEach(function(item, i) {
            // proName=abc;
            // size=10;
            var itemArr = item.split('=');
            // ['proName','abc']
            // ['size',10]
            obj[itemArr[0]] = decodeURIComponent(itemArr[1]); //值是转码后的字符串  需要在对象中显示正常字符串
        })
    }
    return obj;
}