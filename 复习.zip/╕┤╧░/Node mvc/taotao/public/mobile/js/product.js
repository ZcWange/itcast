$(function() {
    // mui('.mui-scroll-wrapper').scroll();
    // 1. 初始化页面  自动触发下一次下拉刷新  渲染商品详情
    // 2. 当主动去下拉操作  渲染商品详情
    // 3. 初始化页面  尺码选择功能实现
    // 4. 点击加入购物车  获取尺寸数量去请求后台 进行加入购物车的操作(登录)
    // 5. 后台给予响应的时候:
    // - 未登录  返回的json中会有提示  跳转去登录页面  登录完成后 返回原页面
    // - 已登录  根据数据判断是否添加成功
    // - 如果成功: 弹出提示  点击确认跳转购物车页面
    new App();
})
var App = function() {
    // 待渲染
    this.$el = $('.mui-scroll')
    // 获取ID
    this.proId = tt.getParamsByUrl().proId;
    this.init();
}
App.prototype.init = function() {
    var that = this;
    that.initPullRefreshDown();
    that.bindEvent();
}
App.prototype.render = function(callback) {
    var that = this;
    $.ajax({
        type: 'get',
        url: '/product/queryProductDetail',
        data: {
            id: that.proId
        },
        dataType: 'json',
        success: function(data) {
            setTimeout(function() {
                callback && callback(data);
            }, 500)
        }
    })
}
App.prototype.bindEvent = function() {
    var that = this;
    that.$el.on('tap', '.pro_size span', function() {
        that.changeSize(this);
    })
    $('.btn_cart').on('tap', function() {
        that.addCart();
    })
}
App.prototype.initPullRefreshDown = function() {
    var that = this;
    mui.init({
        pullRefresh: {
            container: '.mui-scroll-wrapper',
            indicators: false,
            down: {
                auto: true,
                callback: function() {
                    var _self = this;
                    that.render(function(data) {
                        // 渲染
                        that.$el.html(template('detail', data));
                        // 需要初始化  动态渲染的内容组件
                        mui('.mui-slider').slider();
                        mui('.mui-numbox').numbox();
                        // 清除下拉刷新效果
                        _self.endPulldownToRefresh();
                    })
                }
            }
        }
    })
}
// 选择尺码
App.prototype.changeSize = function(btn) {
    var $curr = $(btn);
    $curr.addClass('now').siblings('span').removeClass('now');
}
// 添加购物车
App.prototype.addCart = function() {
    var that = this;
    // 1. 获取尺寸数量和商品ID去请求后台
    var num = mui('.mui-numbox').numbox().getValue();
    var size = $('.pro_size span.now').data('size');
    // 2. 检验
    if(!size) {
        mui.toast('请选择尺码');
        return;
    }
    // 3. 发送请求
    $.ajax({
        type: 'post',
        url: '/cart/addCart',
        data: {
            size: size,
            num: num,
            productId: that.proId
        },
        dataType: 'json',
        success: function(data) {
            //登录拦截
            if (data.error === 400) {
                // 跳转登录且  附带当前页面地址  转出URL 编码  redirect
                location.href = '/mobile/user/login.html?returnUrl=' + encodeURIComponent(location.href);
                return;
            }
            if (data.success) {
                // 添加成功
                mui.confirm('添加成功', '温馨提示', ['取消', '确认'], function(e) {
                    // 点击按钮回调函数  点击取消和确认都会触发
                    // e === {index:0|1} 0第一个   1 第二个
                    if (e.index === 1) {
                        location.href = '/mobile/user/cart.html';
                    }
                })
            }
        }
    })
}