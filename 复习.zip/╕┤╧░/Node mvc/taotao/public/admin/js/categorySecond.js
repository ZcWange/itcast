$(function () {
    new App();
});
var App = function () {
    this.$el = $('tbody');
    this.page = 1; //默认显示第一页
    this.pageSize = 5; //一页多少条
    this.init();
};
App.prototype.init = function () {
    var that = this;
    that.render(function (data) {
        that.pagination(data);
    });
    that.dropDown();
    that.fileUpload();
    that.bindEvent();
};
App.prototype.bindEvent = function(){
    var that = this;
    $('.btn-primary').on('click',function () {
        that.addCategory();
    });
};
App.prototype.render = function (callback) {
    var that = this;
    $.ajax({
        type: 'get',
        url: '/category/querySecondCategoryPaging',
        data: {
            page: that.page,
            pageSize: that.pageSize
        },
        dataType: 'json',
        success: function (data) {
            that.$el.html(template('list', data));
            callback && callback(data);
        }
    })
};
//做分页业务功能
App.prototype.pagination = function (data) {
    var that = this;
    //1. 使用bootstrap分页组件  ul.pagination  结构
    //2. 使用js插件  bootstrap-paginator
    //3. 初始化
    $('.pagination').bootstrapPaginator({
        //配置选项
        // 如果 使用 3 版本的bootstrap
        bootstrapMajorVersion: 3,
        //一共多少页
        totalPages: Math.ceil(data.total / data.size),
        //现在第几页
        currentPage: data.page,
        //配置显示普通按钮的数量
        numberOfPages: 10,
        //配置按钮点击  返回当前的页码数
        onPageClicked: function (event, originalEvent, type, page) {
            //点击之后的回调函数
            //event jquery的事件对象
            //originalEvent 原生的事件对象
            //type 按钮类型
            //page 当前点击按钮对应的页码
            that.page = page;
            that.render();
        }
    });
};
//做添加业务功能
App.prototype.addCategory = function () {
    var that = this;
    $.ajax({
        type:'post',
        url:'/category/addSecondCategory',
        data:{
            brandName:$('form [name="brandName"]').val(),
            categoryId:$('.dropdown .text').data('id'),
            brandLogo:$('.imgBox img').attr('src')
        },
        dataType:'json',
        success:function (data) {
            if(data.success){
                //更新  渲染第一页
                that.page = 1;
                that.render(function (data) {
                    that.pagination(data);
                });
                //关闭模态框
                $('#addCategory').modal('hide')
            }
        }
    });
};
//做初始化一级下拉菜单业务功能
App.prototype.dropDown = function () {
    var $dropdown = $('.dropdown');
    //在页面加载完成的时候
    $.ajax({
        type: 'get',
        url: '/category/queryTopCategoryPaging',
        data: {
            page: 1,
            pageSize: 10000
        },
        dataType: 'json',
        success: function (data) {
            //渲染下拉菜单 和  点击菜单选择功能
            $dropdown.find('.dropdown-menu')
                .html(template('topCate', data))
                .on('click', 'a', function () {
                    $dropdown.find('.text').html(this.dataset.text).data('id',this.dataset.id);
                });
        }
    });
};
//做初始化上传图片业务功能
App.prototype.fileUpload = function () {
    /*1. jquery-fileupload 组件 github下载*/
    /*2. jquery.ui.widget  jquery.fileupload  资源*/
    /*3. <input type="file" name="pic1" id="fileUpload">  name就是后台的字段名称*/
    /*4. 初始化*/
    $('#fileUpload').fileupload({
        //类似发ajax请求
        url: '/category/addSecondCategoryPic',
        dataType: 'json',
        done: function (e, data) {
            //完成了上传  后台返回了图片地址
            //console.log(data);
            //console.log(data.result.picAddr);
            var src = data.result.picAddr;
            $('.imgBox img').attr('src', src);
        }
    });
};
