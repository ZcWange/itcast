$(function() {
    $('#loginForm').on('submit', function(e) {
        e.preventDefault()
        // 获取表单数据
        var data = {
            username: $('[name="username"]').val(),
            password: $('[name="password"]').val()
        }
        // 做一些校验
        if (!data.username) {
            // 提示
            $('.text-danger').html('用户名必填')
            return;
        }
        if (!data.password) {
            $('.text-danger').html('密码必填');
            return;
        }
        // 发送数据
        $.ajax({
            type: 'post',
            url: '/employee/employeeLogin',
            data: data,
            dataType: 'json',
            success: function(data) {
                if (data.success) {
                    // 登录成功
                    location.href = '/admin/index.html';
                } else if (data.error === 1000) {
                    // 用户名不存在
                    $('.text-danger').html('用户名不存在');
                } else if (data.error === 1001) {
                    // 密码错误
                    $('.text-danger').html('密码错误');
                } else {
                    $('.text-danger').html('网络异常');
                }
            }
        })
    })
})