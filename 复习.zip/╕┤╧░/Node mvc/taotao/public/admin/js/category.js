$(function() {
    // 使用面向对象来组织
    new App();
    // 1. 页面初始化的时候  获取第一特的二级分类数据 且完成渲染
    // 2. 页面初始化的时候 渲染分类按钮(使用插件 boostrap-paginator)
    // 3. 点击添加品牌  弹出模态框 静态的内容(下拉菜单 输入框 上传图片按钮 预览图片的区域)
    // 4. 初始化  下拉菜单 初始化 上传图片 (jquery-fileupload)
    // 5. 点击模态框的确认按钮  提交输入和选择的信息给后台  进行添加操作
    // 6. 响应成功操作添加成功  关闭模态框 重新渲染列表而且是第一页
})
var App = function() {
    this.page = 1,
        this.pageSize = 5;
    this.$el = $('tbody');
    this.init();
}
App.prototype.init = function() {
    var that = this;
    that.render(function(data) {
        that.pagerInit(data);
    });
    that.bindEvent();
    that.modePluginsInit();
}
App.prototype.render = function(callback) {
    var that = this;
    $.ajax({
        type: 'get',
        url: '/category/querySecondCategoryPaging',
        data: {
            page: that.page,
            pageSize: that.pageSize
        },
        dataType: 'json',
        success: function(data) {
            // 渲染
            that.$el.html(template('list', data));
            // 调用回调
            callback && callback(data);
        }
    })
}
App.prototype.bindEvent = function() {
    var that = this;
    $('#addCategory .btn-primary').on('click', function() {
        that.saveBrand();
    })
    $('#addCategory').on('hidden.bs.modal', function() {
        $('.dropdown .text').html('请选择').data('id','');
        $('[name="brandName"]').val('');
        $('.imgBox img').attr('src','images/none.png');
    });
}
App.prototype.modePluginsInit = function() {
    // 初始化  下拉菜单  上传图片
    this.dropDown();
    // 初始化上传组件
    this.fileUpload();
}
App.prototype.dropDown = function() {
    // 下拉菜单
    $.ajax({
        type: 'get',
        url: '/category/queryTopCategoryPaging',
        data: {
            page: 1,
            pageSize: 10000 //设置的目的是获取所有分类 
        },
        dataType: 'json',
        success: function(data) {
            // 第一种方法
            // var html = '';
            // data.rows.forEach(function (val) {
            //     html += `<li><a href="javascript:;">+ val.categoryName +</a></li>`;
            // })
            // $('.dropdown-men').html(html);
            // 第二种方法 array reduce 遍历 html 上一次遍历后的返回值  val 当前遍历的对象
            // '' 字符串 代表初始值
            $('.dropdown-menu').html(data.rows.reduce(function(html, val) {
                return html + `<li><a href="javascript:;" data-id="${val.id}" data-name="${val.categoryName}">${val.categoryName}</a></li>`;
            }, '')).on('click', 'li a', function() {
                // 把你点击的元素的内容设置为下拉菜单
                $('.dropdown .text').html(this.dataset.name).data('id', this.dataset.id);
            })
        }
    })
}

// 上传图片功能
App.prototype.fileUpload = function() {
    // 插件的使用 jquery - fileupload 插件
    // jquery.js
    // jquery.ui.widget.js  基于jqueryUI的组件库
    // jquery.fileupload.js  核心文件 
    // 使用和ajax 差不多   url 参数{key后台需要的字段名称: value 文件数据} dataType   succsess
    // 上传图片的input
    $('#fileUpload').fileupload({
        url: '/category/addSecondCategoryPic',
        // 在input设置name 就是字段名称
        dataType: 'json',
        done: function(e, data) {
            var src = data.result.picAddr;
            $('.imgBox img').attr('src', src);
        }
    })
}

// 做分页业务功能
App.prototype.pagerInit = function(data) {
    var that = this;
    // 初始化   分页插件
    $('.pagination').bootstrapPaginator({
        // 如果是v3 的boostrap  必须配置一个参数 bootstrapMajorVersion
        bootstrapMajorVersion: 3,
        size: 'small',
        // 当前第几页
        currentPage: data.page,
        // 当前一共多少页  数据获取之后
        totalPages: Math.ceil(data.total / data.size),
        // 显示多少个分页按钮
        onPageClicked: function(event, originalEvent, type, page) {
            // 点击之后的回调函数
            // event jquery 的事件对象
            // originalEvent  原生的事件对象
            // type 按钮类型
            // page 当前点击按钮对应的页码
            that.page = page;
            that.render();
        }
    })
}
App.prototype.showModel = function() {
    // 弹出模态框
    $('#addCategory').modal('show');
}
App.prototype.saveBrand = function() {
    var that = this;
    // 添加品牌
    var categoryId = $('.dropdown .text').data('id');
    var brandName = $('[name="brandName"]').val();
    var brandLogo = $('.imgBox img').attr('src');

    // 校验
    if (!categoryId) {
        $('.text-danger').html('请选择顶级分类')
        return;
    }
    if (!brandName) {
        $('.text-danger').html('请输入品牌名称')
        return;
    }
    if (!brandLogo) {
        $('.text-danger').html('请上传品牌LOGO')
        return;
    }

    $.ajax({
        url: '/category/addSecondCategory',
        type: 'post',
        data: {
            categoryId,
            brandName,
            brandLogo
        },
        dataType: 'json',
        success: function(data) {
            if (data.success) {
                // 关闭模态框
                $('#addCategory').modal('hide');
                that.page = 1;
                that.render(function(data) {
                    that.pagerInit(data);
                })
            }
        }
    })
}