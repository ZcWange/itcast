$(function() {
    /*1.侧边栏显示隐藏*/
    $('[data-menu]').on('click', function() {
        $('aside').toggle();
        $('section').toggleClass('menu');
    });
    /*2.菜单的滑入滑出*/
    $('.menu a[href="javascript:;"]').on('click', function() {
        $(this).next('div').slideToggle();
    });

    // 3. 使用进度条
    // NProgress.start()
    $(window).ajaxStart(function() {
        // 只要发起了ajax就会触发这个事件
        NProgress.start();
    }).ajaxStop(function() {
        // 只要发起ajax就会触发这个事件
        NProgress.done();
    })

    // 4. 退出
    var modelHtml = `<div id="logoutModal" class="modal fade">
        <div class="modal-dialog modal-sm">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal"><span>&times;</span></button>
                    <h4 class="modal-title">温馨提示</h4>
                </div>
                <div class="modal-body">
                    <p class="text-danger">您确定退出吗?</p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">取消</button>
                    <button type="button" class="btn btn-primary">确认</button>
                </div>
            </div>
        </div>
    </div>`;
    $('body').append(modelHtml);
    $('[data-logout]').on('click', function() {
        // 显示模态框
        $('#logoutModal').modal('show')
    })
    $('#logoutModal .btn-primary').on('click', function() {
        $.ajax({
            type: 'get',
            url: '/employee/employeeLogout',
            data: '',
            dataType: 'json',
            success: function(data) {
                if (data.success) {
                    location.href = '/admin/login.html';
                }
            }
        })
    })
    // 1. 需要一个模态框
    // 1.1 boostrap 文档中拷贝模板
    // 1.2 准备一个按钮  button -> data-toggle="modal" data-target="#logoutModal"
    // 1.3 准备一个a 标签 -> data-target = "modal"  href ="#logoutMoadl"
    // 1.4 注意: 页面提前准备好模态框和按钮结构  boostrap 才会初始化

    // 2. 每个页面都需要退出
    // 2.1 公用的JS中定义一个模态框字符串  页面追加上去即可
    // 2.2 需要通过js 绑定退出按钮的点击事件  通过方法去调用显示模态框 $('#logoutModal').modal('show');

    // 3. 绑定确认按钮的点击事件  等模态框追加之后绑定
    // 3.1 发送ajax给后台进行退出
    // 3.2  发送前调用NProgress  注意这个页面引入
    
});