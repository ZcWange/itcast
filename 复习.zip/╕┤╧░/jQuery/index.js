// 后端的数据
var datas = [
  { pName: '飞鸽牌自行车', pCount: 2, price: 200 },
  { pName: 'iPhoneX', pCount: 1, price: 8000 },
  { pName: '飞鸽牌自行车', pCount: 2, price: 200 },
  { pName: '三陵老粗布', pCount: 4, price: 100 },
  { pName: '荣耀8', pCount: 2, price: 1600 },
  { pName: '荣耀9', pCount: 1, price: 2100 },
  { pName: '水杯', pCount: 10, price: 5 },
  { pName: '奶粉', pCount: 30, price: 6 }
];

//【动态生成表格】
$('#btn').click(function () {
  // 1. 循环遍历数组，创建tr追加到tbody中
  for (var i = 0; i < datas.length; i++) {
    var o = datas[i];
    // 创建tr
    var $tr = $('<tr></tr>');
    // 追加到tbody中
    $tr.appendTo('tbody');
    // 2. 根据数据创建td追加到tr中
    // 创建第1个td
    $('<td><input type="checkbox"></td>').appendTo($tr);
    // 创建第2个td
    $('<td></td>').text(o.pName).appendTo($tr);
    // 创建第3个td
    var $td3 = $('<td></td>');
    $('<button class="reduce">-</button>').appendTo($td3);
    $('<input type="text"  readonly>').val(o.pCount).appendTo($td3);
    $('<button class="add">+</button>').appendTo($td3);
    $td3.appendTo($tr);
    // 创建第4个td
    $('<td></td>').text(o.price).appendTo($tr);
    // 创建第5个td
    $('<td></td>').text(o.price * o.pCount).appendTo($tr);
    //创建第6td
    $('<td><a href="javascript:" class="del">删除</a></td>').appendTo($tr);
  }
  // 3. 生成表格后给tbody中的每一个多选框注册事件
  fn2();
  // 4. 给加减按钮注册事件实现的功能
  fn4();
  // 5. 给删除按钮注册点击事件
  fn5();
});

//【功能1：全选】
$('#all').click(function () {
  // 获取当前点击的全选按钮的选中状态
  var isC = $(this).prop('checked');
  // 赋值给tbody中所有的多选框
  $('tbody input[type=checkbox]').prop('checked', isC);
  // 计算总价格
  totalPrice();
});

// 【功能2：点击tbody中的多选框，检测thead中是否要全选】
function fn2() {
  $('tbody input[type=checkbox]').click(function () {
    // 找到tbody中选中的多选框的数量
    var v1 = $('tbody input[type=checkbox]:checked').length;
    // 找到tbody中所有多选框的数量
    var v2 = $('tbody input[type=checkbox]').length;
    // 判断是否一致
    if (v1 == v2) {
      $('#all').prop('checked', true);
    } else {
      $('#all').prop('checked', false);
    }
    // 计算总价格
    totalPrice();
  });
}

// 【功能3：计算总价格，函数封装】
function totalPrice() {
  var sum = 0;  // 总价格
  // 获取已经选中的多选框
  var $cks = $('tbody input[type=checkbox]:checked');
  // 循环遍历选中的多选框，根据选中的多选框找当前行的小计累计
  for (var i = 0; i < $cks.length; i++) {
    var td4 = $cks.eq(i)   // 找到对应多选框
      .parent()  // 找到td
      .parent()  // 找到tr
      .children() // 找到所有td
      .eq(4);     // 筛选出小计
    // 计算总价格
    sum = sum + Number(td4.text());
  }
  // 赋值给span
  $('.total').text(sum);
};


//【功能4：点击加减按钮实现购物车操作控制】
function fn4() {
  // 给加按钮注册事件
  $('.add').click(function () {
    //--更改文本框--
    // 获取文本框原有的值
    var v = $(this).prev().val();
    v = Number(v) + 1;
    // 设置文本框的值
    $(this).prev().val(v);

    //--更改小计---
    // 获取小计td
    var $td4 = $(this).parent().next().next();
    // 获取单价td
    var $td3 = $(this).parent().next();
    // 设置小计
    var xiaoJi = v * $td3.text();
    $td4.text(xiaoJi);


    //--更改当前行复选框的选中状态--
    $(this).parent().prev().prev().find('input').prop('checked', true);

    //-- 计算总价格--
    totalPrice();


  });

  // 给减按钮注册事件
  $('.reduce').click(function () {
    //--更改文本框--
    // 获取文本框原有的值
    var v = $(this).next().val();
    v = Number(v) - 1;
    if (v < 1) {
      v = 1;
    }
    // 设置文本框的值
    $(this).next().val(v);

    //--更改小计---
    // 获取小计td
    var $td4 = $(this).parent().next().next();
    // 获取单价td
    var $td3 = $(this).parent().next();
    // 设置小计
    var xiaoJi = v * $td3.text();
    $td4.text(xiaoJi);


    //--更改当前行复选框的选中状态--
    $(this).parent().prev().prev().find('input').prop('checked', true);

    //-- 计算总价格--
    totalPrice();
  });

};


//【功能5：点击删除按钮实现删除】
function fn5() {
  $('.del').click(function () { 
    var isOk = confirm('您真的不要了吗？');
    if (isOk) {
      // 找到tr删除
      $(this).parent().parent().remove();
      // 重新计算总价格
      totalPrice();
    }
  });
}

//【功能6：清空购物车】
$('#clear').click(function () { 

  $('tbody').empty();
  // $('tbody').html('');
  totalPrice();
});
